define( function ( require ) {

	"use strict";

	return {
		app_slug : 'advogadus',
		wp_ws_url : 'http://www.konsultorius.webpress.net.br/advogado1/wp-appkit-api/advogadus',
		wp_url : 'http://www.konsultorius.webpress.net.br/advogado1',
		theme : 'q-android',
		version : '0.1',
		app_type : 'phonegap-build',
		app_title : 'Advogado Modelo 1',
		app_platform : 'android',
		app_path: '',
		gmt_offset : 0,
		debug_mode : 'off',
		auth_key : '!+|Pz%:*InP/|^,6A-)([;:.<|%v$#DKi-aP|=y&VK9SDWgmw6BY%r(q<)h5W%3 ',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
